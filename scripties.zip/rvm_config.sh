#!/bin/bash
# Locally copied script
rvm install ruby-2.2.3
rvm --default use ruby-2.2.3
gem install bundler --no-rdoc --no-ri
sudo mkdir -p /home/2Doer/.ssh
sudo sh -c "cat /home/localuser/.ssh/authorized_keys >> /home/2Doer/.ssh/authorized_keys"
sudo chown -R 2Doer /home/2Doer/.ssh
sudo chmod 700 /home/2Doer/.ssh
sudo sh -c "chmod 600 /home/2Doer/.ssh/*"
sudo mkdir -p /var/www/2Doer
sudo chown 2Doer: /var/www/2Doer
cd /var/www/2Doer
sudo -u 2Doer -H git clone git://github.com/minttusofia/2Doer code
bundle install