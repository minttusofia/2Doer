#!/bin/bash
printf "Enter gateway user to connect to :\n>"
read GATE
printf "Enter cs user vm to connect to :\n> "
read USER
ssh -M -S ~/staging.sock -fnNTt $SETTINGS -L 3030:stud$USER-p:22 $GATE@newgate.cs.ucl.ac.uk
ssh -t -p 3090 $SETTINGS root@localhost 'cd /var/www/2Doer/code/2doer_app && rvmsudo bundle exec passenger stop && git -u 2Doer -H git cline git://github.com/minttusofia/2Doer code && rvmsudo bundle exec passenger start'
ssh -S ~/staging.sock -O exit $GATE@newgate.cs.ucl.ac.uk