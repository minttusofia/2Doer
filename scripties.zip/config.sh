#!/bin/bash
# Locally used scrip to set up initial packages
sudo yum list installed > ~/setup/installed.txt
perl ~localuser/setup/rm_common.pl -f ~localuser/setup/installed.txt ~localuser/setup/minimal.txt > ~localuser/setup/rm_list.txt 
INPUT1=~localuser/setup/rm_list.txt
printf "Deleting"
while read package
do
        yum remove -y $package
done < $INPUT1
INPUT2=~localuser/setup/add_list.txt
while read package
do
        $package
done < $INPUT2
sudo gpg2 --keyserver hkp://keys.gnupg.net --recv-keys 409B6B1796C275462A1703113804BB82D39DC0E3
curl -sSL https://get.rvm.io | sudo bash -s stable
if sudo grep -q secure_path /etc/sudoers; then
        sudo sh -c "echo export rvmsudo_secure_path=1 >> /etc/profile.d/rvm_secure_path.sh"
fi