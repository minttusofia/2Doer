#!/bin/bash
# Run second as RVM needs a relog in order to be functional
SETTINGS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
printf "Enter gateway to connect to :\n> "
read GATE
echo "$HOSTNAME"
printf "Enter cs vm user to connect to :\n> "
read USER
ssh -M -S ~/config.sock -fntNT $SETTINGS -L 3030:stud$USER-p:22 $GATE@newgate.cs.ucl.ac.uk
scp -P 3030 $SETTINGS ./rvm_config.sh root@localhost:/root/rvm_config.sh
ssh -t -p 3030 $SETTINGS root@localhost 'chmod 700 ~/rvm_config.sh && ./rvm_config.sh'
scp -P 3030 $SETTINGS ./2Doerconfig.sh 2Doer@localhost:/home/2Doer/2Doerconfig.sh
ssh -t -p 3030 $SETTINGS root@localhost 'chmod 777 /home/2Doer/2Doerconfig.sh'
ssh -t -p 3030 $SETTINGS 2Doer@localhost './2Doerconfig.sh'
ssh -t p 3030 $SETTINGS localuser@localhost 'cd /var/www/2Doer/code/2doer_app && rvmsudo bundle exec passenger start'
ssh -S ~/config.sock -O exit $GATE@newgate.cs.ucl.ac.uk