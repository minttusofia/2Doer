#!/bin/bash
# Locally copied script to be run as 2Doer user
rvm use ruby-2.2.3
cd /var/www/2Doer/code/2doer_app
ls
bundle install --deployment --without development test
chmod 700 config db
chmod 600 config/database.yml config/secrets.yml
bundle exec rake assets:precompile db:migrate RAILS_ENV=production