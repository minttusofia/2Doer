#!/bin/bash
# Run first to setup initial config
SETTINGS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
printf "Enter gateway user to connect to :\n>"
read GATE
printf "Enter cs user vm to connect to :\n> "
read USER
ssh -M -S ~/config.sock -fnNTt $SETTINGS -L 3030:stud$USER-p:22 $GATE@newgate.cs.ucl.ac.uk
scp -P 3030 $SETTINGS -r ../setup localuser@localhost:/home/localuser
ssh -t -p 3030 $SETTINGS root@localhost 'groupadd rvm'
ssh -t -p 3030 $SETTINGS root@localhost 'usermod -a -G rvm localuser'
ssh -t -p 3030 $SETTINGS localuser@localhost 'chmod 700 ~/setup/config.sh && sudo yum install -y perl && sudo ~localuser/setup/config.sh'
ssh -S ~/config.sock -O exit $GATE@newgate.cs.ucl.ac.uk